# Factory Briefing Packet Index

## Quick Start
1. Review SPEC-001.md for requirements
2. Review SPEC-002_briefing-packet.md for approach
3. Check briefing/ for implementation guidance
4. Use .github/workflows/ as templates

## Key Files
- briefing/index.md - Main briefing entry point
- briefing/prompting/contract.md - LLM interaction rules
- IMPLEMENTATION_PLAN.md - Development roadmap

## Citation Format
When referencing this packet, use:
`Per briefing/[section]/[file].md#anchor`
